<?php return array (
  'admin.posts-index' => 'App\\Http\\Livewire\\Admin\\PostsIndex',
  'admin.users-indexx' => 'App\\Http\\Livewire\\Admin\\UsersIndexx',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);