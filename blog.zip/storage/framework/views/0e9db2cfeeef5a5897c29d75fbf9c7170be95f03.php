

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Lista de usuarios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.users-indexx')->html();
} elseif ($_instance->childHasBeenRendered('kYaABR6')) {
    $componentId = $_instance->getRenderedChildComponentId('kYaABR6');
    $componentTag = $_instance->getRenderedChildComponentTagName('kYaABR6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kYaABR6');
} else {
    $response = \Livewire\Livewire::mount('admin.users-indexx');
    $html = $response->html();
    $_instance->logRenderedChild('kYaABR6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp\htdocs\blog2021\resources\views/admin/users/index.blade.php ENDPATH**/ ?>