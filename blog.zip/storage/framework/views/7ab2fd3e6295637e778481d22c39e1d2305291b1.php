

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear Nuevo Rol</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="card">
            <div class="card-body">
                <?php echo Form::open(['route' => 'admin.roles.store']); ?>

                    
                    <?php echo $__env->make('admin.roles.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo Form::submit('Crear Role',['class' => 'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp\htdocs\blog2021\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>