

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.posts.create')): ?>
        
    <a class="btn btn-secondary float-right" href="<?php echo e(route('admin.posts.create')); ?>">Nuevo Post</a>
    <?php endif; ?>

    <h1>Listado de post</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <?php if(session('info')): ?>
            <div class="alert alert-success">
                <strong><?php echo e(session('info')); ?></strong>
            </div>
        <?php endif; ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.posts-index')->html();
} elseif ($_instance->childHasBeenRendered('UAL2wDx')) {
    $componentId = $_instance->getRenderedChildComponentId('UAL2wDx');
    $componentTag = $_instance->getRenderedChildComponentTagName('UAL2wDx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UAL2wDx');
} else {
    $response = \Livewire\Livewire::mount('admin.posts-index');
    $html = $response->html();
    $_instance->logRenderedChild('UAL2wDx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp\htdocs\blog2021\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>